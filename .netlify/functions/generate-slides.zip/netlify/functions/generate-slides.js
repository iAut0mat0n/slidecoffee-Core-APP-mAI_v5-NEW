var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/generate-slides.ts
var generate_slides_exports = {};
__export(generate_slides_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(generate_slides_exports);
var MANUS_API_URL = process.env.BUILT_IN_FORGE_API_URL || "";
var MANUS_API_KEY = process.env.BUILT_IN_FORGE_API_KEY || "";
var handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const { plan, brand } = JSON.parse(event.body || "{}");
    if (!plan) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Presentation plan is required" })
      };
    }
    const response = await fetch(`${MANUS_API_URL}/v1/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${MANUS_API_KEY}`
      },
      body: JSON.stringify({
        model: "gemini-2.0-flash-exp",
        messages: [
          {
            role: "system",
            content: `You are a professional presentation designer. Generate detailed slide content based on the provided plan.

For each slide, provide:
- Title
- Content (bullet points, paragraphs, or structured data)
- Layout type (title, content, two-column, image-text, etc.)
- Design notes

${brand ? `Apply these brand guidelines:
- Primary Color: ${brand.primary_color}
- Secondary Color: ${brand.secondary_color}
- Font Heading: ${brand.font_heading}
- Font Body: ${brand.font_body}` : ""}

Return the slides as a JSON array.`
          },
          {
            role: "user",
            content: `Generate slides for this presentation plan:

${JSON.stringify(plan, null, 2)}`
          }
        ],
        temperature: 0.7,
        max_tokens: 2e3,
        response_format: { type: "json_object" }
      })
    });
    if (!response.ok) {
      throw new Error(`Manus API error: ${response.statusText}`);
    }
    const data = await response.json();
    const slidesContent = data.choices[0]?.message?.content || "{}";
    const slides = JSON.parse(slidesContent);
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        slides: slides.slides || [],
        usage: data.usage
      })
    };
  } catch (error) {
    console.error("Slide Generation Error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: "Failed to generate slides",
        details: error instanceof Error ? error.message : "Unknown error"
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
